<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\ApiService;


class HomeController extends Controller
{

    private $api;

    public function __construct()
    {
        $this->api = new ApiService();
    }

    public function index()
    {
        $descricao_personagem = $this->api->GET('descricao_heroi');
        $data['descricao_personagem'] = $descricao_personagem['dados']['descricao_heroi'];

        $batalha_ativa = $this->api->GET('batalha_ativa');
        $data['batalha_ativa'] = $batalha_ativa['dados']['batalha'];

        return view('tela_inicial',$data);
    }

    public function store(Request $request)
    {
        $parametros = $request->all();
        $params['nome']                 = $parametros['nickname'];
        $params['id_personagem']        = $parametros['id_personagem'];
        $params['created_at']           = date('Y-m-d H:i:s');
        $params['updated_at']           = date('Y-m-d H:i:s');
        $jogador = $this->api->POST('jogador', ['form_params' => $params]);
        $jogador = json_decode($jogador['dados']);



        $heroi      = $this->api->GET('personagem/'.$parametros['id_personagem']);
        $monstro    = $this->api->GET('monstros_randomicos');

        $params_batalha['rodada']               = 0;
        $params_batalha['status']               = 1;
        $params_batalha['id_heroi']             = $heroi['dados']['personagem']['id'];
        $params_batalha['id_monstro']           = $monstro['dados']['monstro']['id'];
        $params_batalha['id_jogador']           = $jogador->jogador->id;
        $params_batalha['created_at']           = date('Y-m-d H:i:s');
        $params_batalha['updated_at']           = date('Y-m-d H:i:s');

        $this->api->POST('batalha', ['form_params' => $params_batalha]);

        return response()->json(['success'=> true],200);

    }

}

