<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\ApiService;


class BatalhaController extends Controller
{

    private $api;

    public function __construct()
    {
        $this->api = new ApiService();
    }

    public function show($id)
    {

        $jogador = $this->api->GET('jogador/'.$id);
        $batalha = $this->api->GET('batalha/'.$id);
        $batalha = $batalha['dados']['batalha'];
        $heroi      = $this->api->GET('personagem/'.$batalha['id_heroi']);
        $monstro    = $this->api->GET('personagem/'.$batalha['id_monstro']);
        $data['heroi'] = $heroi['dados']['personagem'];
        $data['monstro'] = $monstro['dados']['personagem'];
        $data['jogador'] = $jogador['dados']['jogador'];
        $data['id_batalha'] = $id;
        $data['batalha'] = $batalha;



        return view('tela_batalha',$data);
    }

    public function store(Request $request)
    {
        $parametros = $request->all();
        $params['nome']                 = $parametros['nickname'];
        $params['id_personagem']        = $parametros['id_personagem'];
        $params['created_at']           = date('Y-m-d H:i:s');
        $params['updated_at']           = date('Y-m-d H:i:s');
        $this->api->POST('jogador', ['form_params' => $params]);

        $heroi      = $this->api->GET('personagem/'.$parametros['id_personagem']);
        $monstro    = $this->api->GET('monstros_randomicos');

        $params_batalha['rodada']               = 0;
        $params_batalha['status']               = 1;
        $params_batalha['id_heroi']             = $heroi['dados']['personagem']['id'];
        $params_batalha['id_monstro']           = $monstro['dados']['monstro']['id'];
        $params_batalha['created_at']           = date('Y-m-d H:i:s');
        $params_batalha['updated_at']           = date('Y-m-d H:i:s');

        $this->api->POST('batalha', ['form_params' => $params_batalha]);

        return response()->json(['success'=> true],200);

    }

    public function update(Request $request, $id)
    {
        $parametros = $request->all();
        $batalha = $this->api->GET('batalha/'.$id);
        $batalha = $batalha['dados']['batalha'];
        if(isset($parametros['status'])){
            $params['status']                   = $parametros['status'];
        }
        if(isset($parametros['vida_monstro'])){
            $params['vida_monstro']             = $parametros['vida_monstro'];
        }
        if(isset($parametros['vida_heroi'])){
            $params['vida_heroi']               = $parametros['vida_heroi'];
        }
        $params['updated_at']                   = date('Y-m-d H:i:s');
        $params['rodada']                       = $parametros['rodada'] + $batalha['rodada'];

        return $this->api->PUT('batalha/' . $id, [
            'form_params' => $params
        ]);
    }
    public function rankBatalhas( )
    {
        $batalha = $this->api->GET('rank_batalha');
        $batalha = $batalha['dados']['batalhas'];
        $data['batalhas'] = $batalha;

        $descricao_personagem = $this->api->GET('descricao');
        $data['descricao_personagem'] = $descricao_personagem['dados']['descricao'];

        $nome_jogador = $this->api->GET('nome_jogador');
        $data['nome_jogador'] = $nome_jogador['dados']['nome'];

        return view('tela_rank',$data);

    }


}

