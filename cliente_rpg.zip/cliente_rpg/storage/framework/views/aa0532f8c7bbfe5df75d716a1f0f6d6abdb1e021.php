
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="accordion accordion-flush" id="accordionFlushExample">
            <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingOne">
                    <a href="/" class="btn bg-navy margin pull-right" > </i> Tela de Cadastro</a>
                    <a href="/rank_batalhas" class="btn bg-navy margin pull-right" > </i> Classificação Jogadores</a><br>
                </h2>
            </div>
          </div>
        <div class="card text-center">
            <div class="card-header">
                <h3 class="box-title">Curriculos Cadastrados</h3>
            </div>
            <div class="container">
                <div class="row">
                    <div class="one-third column">
                        <table class="table table-striped">
                            <thead>
                                <th>Classificação</th>
                                <th>Nome</th>
                                <th>Status Batalha</th>
                                <th>Classe Personagem</th>
                                <th>Classe Monstro</th>
                                <th>Vida Heroi</th>
                                <th>Vida Monstro</th>
                                <th>Quantidade de Rodadas</th>
                            </thead>
                            <tbody>
                                <?php $rank = 1;?>
                                <?php $__currentLoopData = $batalhas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batalha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($rank); ?>°</td>
                                        <td><?php echo e(isset($nome_jogador[$batalha['id_jogador']]) ? $nome_jogador[$batalha['id_jogador']] : ''); ?></td>
                                        <?php if($batalha['status'] == 1): ?>
                                            <td>Em Andamento</td>
                                        <?php else: ?>
                                            <td>Finalizada</td>
                                        <?php endif; ?>
                                        <td><?php echo e(isset($descricao_personagem[$batalha['id_heroi']]) ? $descricao_personagem[$batalha['id_heroi']] : ''); ?></td>
                                        <td><?php echo e(isset($descricao_personagem[$batalha['id_monstro']]) ? $descricao_personagem[$batalha['id_monstro']] : ''); ?></td>
                                        <td><?php echo e(isset($batalha['vida_heroi']) ? $batalha['vida_heroi'] : ''); ?></td>
                                        <td><?php echo e(isset($batalha['vida_monstro']) ? $batalha['vida_monstro'] : ''); ?></td>
                                        <td><?php echo e(isset($batalha['rodada']) ? $batalha['rodada'] : ''); ?></td>
                                    </tr>
                                    <?php $rank ++;?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\WWW\api_rpg\cliente_rpg\resources\views/tela_rank.blade.php ENDPATH**/ ?>