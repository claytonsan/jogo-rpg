<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="accordion accordion-flush" id="accordionFlushExample">
            <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingOne">
                    <a href="/" class="btn bg-navy margin pull-right" > </i> Tela de Cadastro</a>
                    <a href="/rank_batalhas" class="btn bg-navy margin pull-right" > </i> Classificação Jogadores </a><br>
                </h2>
            </div>
        </div><br>
        <section class="content">
            <div class="box box-default">
                <div class="container">
                    <div class="row">
                        <div class="one-third column">
                            <div class="box-header with-border">
                                <h3 class="box-title"><i class="fa fa-user-plus"></i> Tela de Cadastro</h3>
                            </div><br>
                            <form id="form_novo_personagem" role="form">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <div class="col-lg-6 col-xs-12">
                                        <label>Nickname: </label>
                                        <input type="text" class="form-control nickname" name="nickname" >
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-6 col-xs-12">
                                        <label>Personagem: </label>
                                    <?php echo Form::select('id_personagem', $descricao_personagem, null , array('class'=>'form-control chosen-select', 'id' => 'id_personagem')); ?>

                                    </div>
                                </div>
                                <br>
                                <?php if(isset($batalha_ativa) && ($batalha_ativa != '')): ?>
                                    <div class="box-footer">
                                        <a href="/batalhar/<?php echo e($batalha_ativa['id']); ?>" class="btn btn-primary  btn-xs pull-right" > </i> Ir a Ultima Batalha</a>
                                    </div>
                                <?php else: ?>
                                    <div class="box-footer">
                                        <button class="btn btn-primary  btn-xs pull-right" id="bt_salvar">Salvar</button>
                                    </div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
        <script>

        $(function () {
            $("#bt_salvar").click(function (e) {
            e.preventDefault();
            $("#bt_salvar").attr('disabled', true);
            var form = $('#form_novo_personagem')[0];
            var data = new FormData(form);
            var nome = $(".nickname").val();
            if((nome == null) || nome == ''){
                alert("Informe seu Nickname");
                location.reload();
            }else{
                $.ajax({
                    type: "POST",
                    enctype: 'multipart/form-data',
                    url: "/",
                    data: data,
                    processData: false, // impedir que o jQuery tranforma a "data" em querystring
                    contentType: false, // desabilitar o cabeçalho "Content-Type"
                    cache: false, // desabilitar o "cache"
                    timeout: 600000, // definir um tempo limite (opcional)
                    success: function (data) {
                        if(data['success']){
                            alert('Personagem cadastrado com sucesso!');
                            location.href = '/';
                        }
                    },
                    error: function (e) {
                        console.log(e);
                        $("#bt_salvar").attr('disabled', false);
                    }
                })
            }
        });

        })

        </script>

    </body>


</html>
<?php /**PATH C:\WWW\api_rpg\cliente_rpg\resources\views/tela_inicial.blade.php ENDPATH**/ ?>