<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="accordion accordion-flush" id="accordionFlushExample">
            <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingOne">
                    <a href="/" class="btn bg-navy margin pull-right" > </i> Tela de Cadastro</a>
                    <a href="/rank_batalhas" class="btn bg-navy margin pull-right" > </i> Classificação Jogadores</a><br>
                </h2>
            </div>
        </div>
        <section class="content">
            <div class="box box-default">
                <div class="container">
                    <form id="form_jogo" role="form">
                    <div class="row">
                        <?php echo csrf_field(); ?>
                        <div class="col-lg-6 col-xs-12">
                            <div class="box box-primary">
                                <div class="box-body box-profile">
                                    <h3 class="profile-username text-center">    <?php echo e($heroi['descricao']); ?> - <?php echo e($jogador['nome']); ?>   </h3>

                                    <ul class="list-group list-group-unbordered">
                                        <li class="list-group-item" id = "vida_heroi" name = "vida_heroi" value="<?php echo e(isset($batalha['vida_heroi']) ? $batalha['vida_heroi'] : $heroi['pontos_vida']); ?>">
                                            <p><b>Pontos de Vida: </b><?php echo e(isset($batalha['vida_heroi']) ? $batalha['vida_heroi'] : $heroi['pontos_vida']); ?> </p> <h1 id="dano_sofrido_heroi"></h1>
                                        </li>
                                        <li class="list-group-item" id = "forca_heroi" name = "forca_heroi" value="<?php echo e($heroi['forca']); ?>">
                                            <p><b>Força: </b><?php echo e($heroi['forca']); ?> </p>
                                        </li>
                                        <li class="list-group-item" id = "defesa_heroi" name = "defesa_heroi" value="<?php echo e($heroi['defesa']); ?>">
                                            <p><b>Defesa: </b><?php echo e($heroi['defesa']); ?> </p>
                                        </li>
                                        <li class="list-group-item" id = "agilidade_heroi" name = "agilidade_heroi" value="<?php echo e($heroi['agilidade']); ?>">
                                            <p><b>Agilidade: </b><?php echo e($heroi['agilidade']); ?> </p>
                                        </li>
                                        <li class="list-group-item" >
                                            <input type="hidden" id = "fator_dano_heroi" name = "fator_dano_heroi" value="<?php echo e($heroi['fator_dano']); ?>">
                                            <p><b>Fator de Dano: </b><?php echo e($heroi['fator_dano']); ?> </p>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Inicio: </b><h1 id="heroi_ini"></h1>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Turnos: </b><h1 id="resultado_primeiro_atk_h"></h1>   <h1 id="resultado_primeira_def_h"></h1>
                                        </li>
                                        <br>
                                        <?php if($batalha['status'] == 1): ?>
                                            <div class="box-footer">
                                                <button class="btn btn-primary  btn-xs pull-right bt_inicio" id="bt_inicio">Batalhar</button>
                                            </div>
                                        <?php else: ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-xs-12">
                            <div class="box box-primary">
                                <div class="box-body box-profile">
                                    <h3 class="profile-username text-center">    <?php echo e($monstro['descricao']); ?>   </h3>

                                    <ul class="list-group list-group-unbordered">
                                        <li class="list-group-item" id = "vida_monstro" name = "vida_monstro" value="<?php echo e(isset($batalha['vida_monstro']) ? $batalha['vida_monstro'] : $monstro['pontos_vida']); ?>">
                                            <p><b>Pontos de Vida: </b><?php echo e(isset($batalha['vida_monstro']) ? $batalha['vida_monstro'] : $monstro['pontos_vida']); ?> </p> <h1 id="dano_sofrido_monstro"></h1>
                                        </li>
                                        <li class="list-group-item" id = "forca_monstro" name = "forca_monstro" value="<?php echo e($monstro['forca']); ?>">
                                            <p><b>Força: </b><?php echo e($monstro['forca']); ?> </p>
                                        </li>
                                        <li class="list-group-item" id = "defesa_monstro" name = "defesa_monstro" value="<?php echo e($monstro['defesa']); ?>">
                                            <p><b>Defesa: </b><?php echo e($monstro['defesa']); ?> </p>
                                        </li>
                                        <li class="list-group-item" id = "agilidade_monstro" name = "agilidade_monstro" value="<?php echo e($monstro['agilidade']); ?>">
                                            <p><b>Agilidade: </b><?php echo e($monstro['agilidade']); ?> </p>
                                        </li>
                                        <li class="list-group-item" >
                                            <input type="hidden" id = "fator_dano_monstro" name = "fator_dano_monstro" value="<?php echo e($monstro['fator_dano']); ?>">
                                            <p><b>Fator de Dano: </b><?php echo e($monstro['fator_dano']); ?> </p>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Inicio: </b><h1 id="monstro_ini"></h1>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Turnos: </b><h1 id="resultado_primeiro_atk_m"></h1>  <h1 id="resultado_primeira_def_m"></h1>
                                        </li>
                                        <br>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </section>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
        <script>

        $(function () {
            var rodada = 0;
            $("#bt_inicio").click(function (e) {
                $("#bt_inicio").hide();

                rodada ++;


                e.preventDefault();
                var form            = $('#form_jogo')[0];
                var data            = new FormData(form);
                var vida_h          = $("#vida_heroi").val();
                var forca_h         = $("#forca_heroi").val();
                var defesa_h        = $("#defesa_heroi").val();
                var agilidade_h     = $("#agilidade_heroi").val();
                var fator_dano_h    = $("#fator_dano_heroi").val();

                var vida_m          = $("#vida_monstro").val();
                var forca_m         = $("#forca_monstro").val();
                var defesa_m        = $("#defesa_monstro").val();
                var agilidade_m     = $("#agilidade_monstro").val();
                var fator_dano_m    = $("#fator_dano_monstro").val();

                dano_heroi          = fator_dano_h.split('d');
                dano_monstro        = fator_dano_m.split('d');
                var finalizado      = 0;

                var heroi_ini = Math.floor((Math.random() * 10) + 1);
                var monstro_ini = Math.floor((Math.random() * 10) + 1);

                if(heroi_ini > monstro_ini){

                    alert('Heroi Incia a Batalha');
                    var primeiro_atk_h = Math.floor((Math.random() * 10) + 1);
                    var primeira_def_m = Math.floor((Math.random() * 10) + 1);

                    var resultado_primeiro_atk_h = primeiro_atk_h + agilidade_h + forca_h ;
                    var resultado_primeira_def_m = primeira_def_m + agilidade_m + defesa_m ;

                    document.getElementById("resultado_primeiro_atk_h" ).innerHTML = resultado_primeiro_atk_h;
                    document.getElementById("resultado_primeira_def_m").innerHTML = resultado_primeira_def_m;

                    if(resultado_primeiro_atk_h > resultado_primeira_def_m){
                        alert('Heroi Ataca');
                        var jogar_dado = 0;
                        var valor_dado_h = 0;
                        while(jogar_dado < dano_heroi[0]){
                            var dano_vida_h = Math.floor((Math.random() * dano_heroi[1]) + 1);
                            valor_dado_h += dano_vida_h;
                            jogar_dado ++;
                        }
                        var dano_tirado_heroi = forca_h + valor_dado_h;
                        var dano_sofrido_monstro = vida_m - dano_tirado_heroi ;
                        document.getElementById("dano_sofrido_monstro").innerHTML = dano_sofrido_monstro;

                        data.append("vida_monstro", dano_sofrido_monstro);
                        data.append("rodada", rodada);

                        if(dano_sofrido_monstro <= 0){
                            alert('Batalha finalizada Heroi Ganhou');
                            data.append("status", finalizado);
                        }

                        $.ajax({
                        type: "POST",
                        enctype: 'multipart/form-data',
                        url: "/batalhar_atualizar/<?php echo e($id_batalha); ?>",
                        data: data,
                        processData: false, // impedir que o jQuery tranforma a "data" em querystring
                        contentType: false, // desabilitar o cabeçalho "Content-Type"
                        cache: false, // desabilitar o "cache"
                        timeout: 600000, // definir um tempo limite (opcional)
                        success: function (data) {
                            location.reload();
                        },

                        });

                    }else{
                        alert('Monstro Defende');
                        $("#bt_inicio").show();
                    }


                }else if(monstro_ini > heroi_ini){

                    alert('Monstro Incia a Batalha');
                    var primeiro_atk_m = Math.floor((Math.random() * 10) + 1);
                    var primeira_def_h = Math.floor((Math.random() * 10) + 1);

                    var resultado_primeiro_atk_m = primeiro_atk_m + agilidade_m + forca_m ;
                    var resultado_primeira_def_h = primeira_def_h + agilidade_h + defesa_h ;

                    document.getElementById("resultado_primeiro_atk_m").innerHTML = resultado_primeiro_atk_m;
                    document.getElementById("resultado_primeira_def_h").innerHTML = resultado_primeira_def_h;

                    if(resultado_primeiro_atk_m > resultado_primeira_def_h){
                        alert('Monstro Ataca');
                        var jogar_dado = 0;
                        var valor_dado_m = 0;
                        while(jogar_dado < dano_monstro[0]){
                            var dano_vida_m = Math.floor((Math.random() * dano_monstro[1]) + 1);
                            valor_dado_m += dano_vida_m;
                            jogar_dado ++;
                        }
                        var dano_tirado_monstro = forca_m + valor_dado_m;
                        var dano_sofrido_heroi = vida_h - dano_tirado_monstro ;
                        document.getElementById("dano_sofrido_heroi").innerHTML = dano_sofrido_heroi;

                        data.append("vida_heroi", dano_sofrido_heroi);
                        data.append("rodada", rodada);

                        if(dano_sofrido_heroi <= 0){
                            alert('Batalha finalizada Monstro Ganhou');
                            data.append("status", finalizado);
                        }

                        $.ajax({
                        type: "POST",
                        enctype: 'multipart/form-data',
                        url: "/batalhar_atualizar/<?php echo e($id_batalha); ?>",
                        data: data,
                        processData: false, // impedir que o jQuery tranforma a "data" em querystring
                        contentType: false, // desabilitar o cabeçalho "Content-Type"
                        cache: false, // desabilitar o "cache"
                        timeout: 600000, // definir um tempo limite (opcional)
                        success: function (data) {
                            location.reload();
                        },

                        });

                    }else{
                        alert('Heroi Defende');
                        $("#bt_inicio").show();
                    }
                }else{
                    alert('Jogue Novamente');
                    $("#bt_inicio").show();
                }

                document.getElementById("heroi_ini").innerHTML = heroi_ini;
                document.getElementById("monstro_ini").innerHTML = monstro_ini;

            });
        })

        </script>

    </body>


</html>
<?php /**PATH C:\WWW\api_rpg\cliente_rpg\resources\views/tela_batalha.blade.php ENDPATH**/ ?>