<?php

use Illuminate\Support\Facades\Route;





Route::resource('/','HomeController');


Route::resource('/batalhar','BatalhaController');
Route::POST('/batalhar_atualizar/{id?}','BatalhaController@update');

Route::get('/rank_batalhas','BatalhaController@rankBatalhas');

