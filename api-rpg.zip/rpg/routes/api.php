<?php

use Illuminate\Support\Facades\Route;


Route::resource('personagem', 'Api\PersonagemController');
Route::get('descricao_heroi', 'Api\PersonagemController@get_descricao_herois');
Route::get('descricao', 'Api\PersonagemController@get_descricao');
Route::get('monstros_randomicos', 'Api\PersonagemController@get_personagens_monstros_randomicos');


Route::resource('jogador', 'Api\JogadorController');
Route::get('nome_jogador', 'Api\JogadorController@get_nome_jogadores');



Route::resource('batalha', 'Api\BatalhaController');
Route::get('batalha_ativa', 'Api\BatalhaController@batalha_ativa');
Route::get('rank_batalha', 'Api\BatalhaController@rank_batalha');
