<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <section class="content">

            <div class="box box-default">
                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-user-plus"></i> Novo Jogo</h3>
                </div>
                <form id="form_novo_personagem" role="form">
                    @csrf
                    <div class="box-body">
                        <div class="col-xs-12">
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="row">
                                        <div class="form-group">
                                            <div class="col-lg-6 col-xs-12">
                                                <label>Nickname: </label>
                                                <input type="text" class="form-control" name="descricao">
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-flat btn-success pull-right" id="bt_salvar"> <i class="fa fa-save"></i> Salvar</button>
                    </div>
                </form>
            </div>

        </section>




        @section('scripts')
        <script src="/bower_components/select2/dist/js/select2.full.min.js"></script>
        <script>
            $(function () {



                $("#bt_salvar").click(function (e) {
                    e.preventDefault();
                    $("#bt_salvar").attr('disabled', true);
                    var form = $('#form_novo_personagem')[0];
                    var data = new FormData(form);
                    $.ajax({
                        type: "POST",
                        enctype: 'multipart/form-data',
                        url: "/rpg",
                        data: data,
                        processData: false, // impedir que o jQuery tranforma a "data" em querystring
                        contentType: false, // desabilitar o cabeçalho "Content-Type"
                        cache: false, // desabilitar o "cache"
                        timeout: 600000, // definir um tempo limite (opcional)
                        success: function (data) {
                            if(data['success']){
                                alert('Equipe cadastrada com sucesso!');
                                location.href = '/rpg/batalha';
                            }
                        },
                        error: function (e) {
                            $("#bt_salvar").attr('disabled', false);
                        }
                    })
                });

            })
        </script>
        @endsection
    </body>
</html>
