<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Batalha extends Model
{
    use SoftDeletes;
    protected $table = 'batalha';
    protected $fillable = [
        'id', 'rodada', 'status','id_jogador','id_heroi','id_monstro','vida_heroi','vida_monstro','created_by' ,'updated_by' ,'deleted_by' ,'created_at' ,'updated_at' ,'deleted_at'
    ];
    protected $dates = ['deleted_at'];
}
