<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Batalha;

class BatalhaController extends Controller
{

    // Retorna todas as Batalhas

    public function index()
    {
        $batalhas = Batalha::all();
        return response()->json(['batalhas'=>$batalhas],200);
    }

    // Cria uma nova Batalha

    public function store(Request $request)
    {
        $dados = $request->all();
        $batalha = Batalha::create($dados);
        if ($batalha) {
            return response()->json(['batalha' => $batalha], 200);
        } else {
            return response()->json(['data' => 'Erro ao criar o batalha'], 400);
        }
    }

    // Busca a batalha pelo ID


    public function show($id)
    {
        $batalha = Batalha::find($id);
        return response()->json(['batalha' => $batalha], 200);
    }


    // metodo para atualizar as informações das batalhas

    public function update(Request $request, $id)
    {
        $dados = $request->all();
        $batalha = Batalha::find($id);
        if($batalha){
            $batalha->update($dados);
            return response()->json(['batalha'=>$batalha],200);
        }else{
            return response()->json(['data'=>'batalha não localizado'],404);
        }
    }


    public function destroy($id)
    {
        //
    }

    // metodo que retorna a batalha ativa

    public function batalha_ativa()
    {
        $batalha = Batalha::where('status', 1)->first();
        return response()->json(['batalha' => $batalha], 200);
    }

    //metodo para salvar o status de cada batalha

    public function get_status_batalha()
    {
        return array(0 => 'Finalizada', 1 => 'Ativa');
    }

    //retorna todas as , vitosiosas, ordenadas por rank de rodadas

    public function rank_batalha()
    {
        $batalhas = Batalha::where('vida_heroi', '>' , 0)->orderBy('rodada')->get();
        return response()->json(['batalhas'=>$batalhas],200);
    }
}
