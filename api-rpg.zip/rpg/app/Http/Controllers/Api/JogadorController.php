<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Jogadores;

class JogadorController extends Controller
{

    // Retorna todos os Jogadores

    public function index()
    {
        $jogadores = Jogadores::all();
        return response()->json(['jogadores'=>$jogadores],200);
    }

    // Salva o jogador

    public function store(Request $request)
    {
        $dados = $request->all();
        $jogador = Jogadores::create($dados);
        if ($jogador) {
            return response()->json(['jogador' => $jogador], 200);
        } else {
            return response()->json(['data' => 'Erro ao criar o jogador'], 400);
        }
    }

    // Busca o jogador pelo ID


    public function show($id)
    {
        $jogador = Jogadores::find($id);
        return response()->json(['jogador' => $jogador], 200);
    }


    public function update(Request $request, $id)
    {
        //
    }


    public function destroy($id)
    {
        //
    }

    //retorna o nome do jogador juntamente com o Id "1 => exemplo"
    public function get_nome_jogadores()
    {
        $nome = Jogadores::pluck('nome', 'id');
        return response()->json(['nome' => $nome], 200);
    }




}
