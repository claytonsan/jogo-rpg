<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Personagens;

class PersonagemController extends Controller
{

    // Retorna todos os Personagens

    public function index()
    {
        $personagens = Personagens::all();
        return response()->json(['personagens'=>$personagens],200);
    }

    // Cria um personagem

    public function store(Request $request)
    {
        $dados = $request->all();
        $personagem = Personagens::create($dados);
        if ($personagem) {
            return response()->json(['personagem' => $personagem], 200);
        } else {
            return response()->json(['data' => 'Erro ao criar o personagem'], 400);
        }
    }

    // Busca os personagens pelo ID


    public function show($id)
    {
        $personagem = Personagens::find($id);
        return response()->json(['personagem' => $personagem], 200);
    }


    public function update(Request $request, $id)
    {
        //
    }


    public function destroy($id)
    {
        //
    }

    //Metodo retorna todos os personagens de Acordo com a sua Classe

    public function get_personagens_classe($classe)
    {
        $herois = Personagens::where('classe_personagem', $classe)->whereNull('deleted_at')->get();
        if ($herois) {
            return response()->json(['herois' => $herois], 200);
        } else {
            return response()->json(['message' => 'Heroi não localizado'], 400);
        }
    }



     //Metodo retorna um personagem Monstro de forma randomica


    public function get_personagens_monstros_randomicos()
    {
        $monstro = Personagens::where('classe_personagem', 2)->orderByRaw("RAND()")->limit(1)->first();
        if ($monstro) {
            return response()->json(['monstro' => $monstro], 200);
        } else {
            return response()->json(['message' => 'Monstro nao localizado'], 400);
        }
    }

    // Metodo para especificação de classe


    public function get_classe_personagem()
    {
        return array(1 => 'Heroi', 2 => 'Monstro');
    }

    //metodo para retornar a descrição do heroi com o id ("1=>paladino")

    public function get_descricao_herois()
    {
        $descricao_heroi = Personagens::where('classe_personagem', 1)->pluck('descricao', 'id');
        return response()->json(['descricao_heroi' => $descricao_heroi], 200);
    }

    //metodo para retornar a descrição da classe com o id ("1=>paladino")

    public function get_descricao()
    {
        $descricao = Personagens::pluck('descricao', 'id');
        return response()->json(['descricao' => $descricao], 200);
    }



}
