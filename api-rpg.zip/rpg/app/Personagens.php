<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Personagens extends Model
{
    use SoftDeletes;
    protected $table = 'personagens';
    protected $fillable = [
        'id', 'descricao', 'pontos_vida','forca', 'defesa' ,'agilidade' ,'fator_dano','classe_personagem','created_by' ,'updated_by' ,'deleted_by' ,'created_at' ,'updated_at' ,'deleted_at'
    ];
    protected $dates = ['deleted_at'];
}
